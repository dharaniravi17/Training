# run_pipeline.py
from pipelines.regression_pipeline import regression_pipeline

if __name__ == "__main__":
    regression_pipeline()
    print("Pipeline executed successfully.")