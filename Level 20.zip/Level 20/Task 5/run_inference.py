from pipelines.inference_pipeline import inference_pipeline

if __name__ == "__main__":
    inference_pipeline()
